/***********************************************************
 * Program Name: MainFrame.java Programmer: Patrick Malahowski Partner: Colin
 * Brust Purpose: To generate game information in a class. file input. Last
 * Changed Date: 3/8/2018
 * **********************************************************
 */
public class Game {

	// variable declaration
	private String Characters;
	private String Scores;
	private String Players;
	private String HighScores;
	private String TopThreeScores;
	private String Enemies;
	private String GameTest;

	// initialize attributes
	public Game(String Characters, String Scores, String Players, String HighScores, String TopThreeScores,
			String Enemies, String GameTest) {
		this.Characters = Characters;
		this.Scores = Scores;
		this.Players = Players;
		this.HighScores = HighScores;
		this.TopThreeScores = TopThreeScores;
		this.Enemies = Enemies;
		this.GameTest = GameTest;
	}

	public String GameTestString() {
		return "" + GameTest + "";
	}

}
