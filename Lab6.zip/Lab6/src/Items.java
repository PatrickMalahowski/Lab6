/***********************************************************
 * Program Name: MainFrame.java Programmer: Patrick Malahowski Partner: Colin
 * Brust Purpose: To generate item information in a class. file input. Last
 * Changed Date: 3/8/2018
 * **********************************************************
 */
public class Items {
	// variable declaration
	private String ItemName;
	private String ItemImage;
	private String ItemPosition;
	private String ItemTest;

	// initialize attributes
	public Items(String ItemName, String ItemImage, String ItemPosition, String ItemTest) {
		this.ItemName = ItemName;
		this.ItemImage = ItemImage;
		this.ItemPosition = ItemPosition;
		this.ItemTest = ItemTest;
	}

	public String ItemTestString() {
		return "" + ItemTest + "";
	}

}
