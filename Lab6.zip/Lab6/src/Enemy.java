/***********************************************************
 * Program Name: MainFrame.java Programmer: Patrick Malahowski Partner: Colin
 * Brust Purpose: To generate enemy information in a class. file input. Last
 * Changed Date: 3/8/2018
 * **********************************************************
 */
public class Enemy {

	// variable declaration
	private String EnemyName;
	private String EnemyImage;
	private String EnemyPosition;
	private String EnemyTest;

	// initialize attributes
	public Enemy(String EnemyName, String EnemyImage, String EnemyPosition, String EnemyTest) {
		this.EnemyName = EnemyName;
		this.EnemyImage = EnemyImage;
		this.EnemyPosition = EnemyPosition;
		this.EnemyTest = EnemyTest;
	}

	public String EnemyTestString() {
		return "" + EnemyTest + "";
	}

}
