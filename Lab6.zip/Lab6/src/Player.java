/***********************************************************
 * Program Name: MainFrame.java Programmer: Patrick Malahowski Partner: Colin
 * Brust Purpose: To generate player information in a class. file input. Last
 * Changed Date: 3/8/2018
 * **********************************************************
 */
public class Player {

	// variable declaration
	private String PlayerName;
	private String PlayerImage;
	private int PlayerItems;
	private String PlayerPosition;
	private String PlayerTest;

	// initialize attributes
	public Player(String PlayerName, String PlayerImage, int PlayerItems, String PlayerPosition, String PlayerTest) {
		this.PlayerName = PlayerName;
		this.PlayerImage = PlayerImage;
		this.PlayerItems = PlayerItems;
		this.PlayerPosition = PlayerPosition;
		this.PlayerTest = PlayerTest;
	}

	public String PlayerTestString() {
		return "" + PlayerTest + "";
	}

}
