/***********************************************************
 * Program Name: MainFrame.java Programmer: Patrick Malahowski Partner: Colin
 * Brust Purpose: To generate movement information in a class. file input. Last
 * Changed Date: 3/8/2018
 * **********************************************************
 */
public class Movement {
	// variable declaration
	private String Keys;
	private String MovementTest;

	// initialize attributes
	public Movement(String Keys, String MovementTest) {
		this.Keys = Keys;
		this.MovementTest = MovementTest;
	}

	public String MovementTestString() {
		return "" + MovementTest + "";
	}

	private boolean areRectsColliding(int r1TopLeftX, int r1BottomRightX, int r1TopLeftY, int r1BottomRightY,
			int r2TopLeftX, int r2BottomRightX, int r2TopLeftY, int r2BottomRightY) {
		if (r1TopLeftX < r2BottomRightX && r1BottomRightX > r2TopLeftX && r1TopLeftY < r2BottomRightY
				&& r1BottomRightY > r2TopLeftY) {
			return true;
		} else {
			return false;
		}
	}

}
