import java.awt.Color;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

/***********************************************************
 * Program Name: MainFrame.java Programmer: Patrick Malahowski Partner: Colin
 * Brust Purpose: To generate game information in a panel based on other
 * classes. I have temporarily added test code for the other classes to the
 * button. Last Changed Date: 3/8/2018
 * **********************************************************
 */

public class MyPanel extends JPanel {// Begin Class

	JLabel TestLabel;

	public MyPanel() {// Begin Constructor

		// set your background color here to your favorite color
		setBackground(Color.GREEN);
		// Set the dimensions of the panel
		setPreferredSize(new Dimension(1349, 691));
		TestLabel = new JLabel();

		// add a button that display a welcome message to the user in a second label.
		JButton myButton = new JButton("Click Here!");
		myButton.addActionListener(new buttonHandler());

		add(myButton);
		add(TestLabel);

	}// End of constructor

	// handler

	private class buttonHandler implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent arg0) {
			// TODO Auto-generated method stub

			// tests
			Items TestItems = new Items("a", "a", "a", "Item Works! ");
			Movement TestMovement = new Movement("a", "Movement Works! ");
			Enemy TestEnemy = new Enemy("a", "a", "a", "Enemy Works! ");
			Player TestPlayer = new Player("a", "a", 1, "a", "Player Works! ");
			Game TestGame = new Game("a", "a", "a", "a", "a", "a", "Game Works! ");

			TestLabel.setText("The button works! " + TestItems.ItemTestString() + TestMovement.MovementTestString()
					+ TestEnemy.EnemyTestString() + TestPlayer.PlayerTestString() + TestGame.GameTestString());

		}

	}

}// End of class
