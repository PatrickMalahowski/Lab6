
import java.awt.Image;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Random;
import java.util.Scanner;

import javax.swing.ImageIcon;

public class Game {
	
	private Player myPlayer;
	private Enemy myEnemy;
	private ImageIcon myPlayerIcon, myEnemyIcon;
	private Items[] myItems = new Items[5];
	private HighScores myHighScores;
	private int originalPlayerX = 0;
	private int originalPlayerY = 0;
	private int originalEnemyX = 1149;
	private int originalEnemyY = 491;
	private MainPanel mainPanel;
	private int xWidth = 1349;
	private int yHeight = 691;
	private int sizeOfFood = 134;
	public Game(MainPanel mainPanel) {
		this.mainPanel = mainPanel;
		
		// choose a player from one of two files
		createPlayer();

		myEnemy = new Enemy("Skull", "./src/Skull.jpg",1149, 491, mainPanel);
		
		// notice how I send information about the enemy into the player here (using the setter)
		myPlayer.setEnemy(myEnemy);
		// same thing here for the player and the enemy so that I can access properties if I want
		myEnemy.setPlayer(myPlayer);
		
		
		myPlayerIcon = new ImageIcon(myPlayer.getImage());
		myEnemyIcon = new ImageIcon(myEnemy.getImage());
		Image newImage = rescaleImage(myPlayerIcon,134, 134);
		myPlayerIcon.setImage(newImage);

		Image newImage2 = rescaleImage(myEnemyIcon,134,134);
		myEnemyIcon.setImage(newImage2);

		// create all the items
		createItems();
		
		myPlayer.setItems(myItems);
		
		// create the high scores - which is just an ArrayList
		myHighScores = new HighScores();
		myPlayer.setHighScores(myHighScores);
		
	}

	public void createPlayer()
	{
		Random myRand = new Random();
		File myFile;
		File myDir = new File("./src/data");
		// get all the files in the directory
		String[] files = myDir.list();
		// choose a random file
		int whichFile = myRand.nextInt(files.length);
		// open that file
		myFile= new File("./src/data/" + files[whichFile]);
		
		Scanner myScanner = null;
		
		try {
			myScanner = new Scanner(myFile);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		while(myScanner.hasNextLine())
		{
			String line = myScanner.nextLine();
			Scanner myLineScanner = new Scanner(line).useDelimiter(",");
			while(myLineScanner.hasNext())
			{
				String name = myLineScanner.next();
				String path = myLineScanner.next();
				int x = myLineScanner.nextInt();
				int y = myLineScanner.nextInt();
				myPlayer = new Player(name,path,x, y, mainPanel);
			}
		}
		
		
	}
	
	// this allows me to rescale any image
	public Image rescaleImage(ImageIcon icon, int width,int height)
	{
		return icon.getImage().getScaledInstance(width, height, Image.SCALE_DEFAULT);
	}
	
	// this just setting the items randomly.. they could be anywhere on the screen
	public void createItems()
	{
		Random myRand = new Random();
		for(int i = 0; i < myItems.length; i++)
		{
			int x = myRand.nextInt(xWidth) + 50;
			int y = myRand.nextInt(yHeight) + 50;
			
			ImageIcon itemIcon = new ImageIcon("./src/Treasure.png");
			
			Image newImage = rescaleImage(itemIcon,sizeOfFood,sizeOfFood);
			itemIcon.setImage(newImage);
			Items myItem = new Items("Item","./src/Treasure.png", x,y, itemIcon);
			myItems[i] = myItem;
		}
	}
	
	// this just resets everything back to the beginning
	public void restart()
	{
		createItems();
		myPlayer.setThePlayerCollidedWithEnemy(false);
		myPlayer.setX(originalPlayerX);
		myPlayer.setY(originalPlayerY);
		myEnemy.setX(originalEnemyX);
		myEnemy.setY(originalEnemyY);
		myEnemy.getMyTimer().start();
		myPlayer.setCurrentScore(0);
		myPlayer.setIsGameOver(false);
		myPlayer.setRespondToKeys(true);
		
	}
	
	public ImageIcon getMyPlayerIcon() {
		return myPlayerIcon;
	}

	public ImageIcon getMyEnemyIcon() {
		return myEnemyIcon;
	}

	public Player getMyPlayer() {
		return myPlayer;
	}

	public Enemy getMyEnemy() {
		return myEnemy;
	}
	
	public Items[] getItems()
	{
		return myItems;
	}
	
	public HighScores getHighScores()
	{
		return myHighScores;
	}

}
