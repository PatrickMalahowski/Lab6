/***********************************************************
 * Program Name: Entity.java Programmer: Patrick Malahowski Partner: Colin Brust
 * Purpose: To generate entity information in a class. file input. Last Changed
 * Date: 4/4/2018 **********************************************************
 */

public class Entity {// Begin Class

	// variable declaration
	protected String Name;
	protected String Image;
	protected int XPosition;
	protected int YPosition;

	// initialize attributes
	public Entity(String Name, String Image, int XPosition, int YPosition) {
		this.Name = Name;
		this.Image = Image;
		this.XPosition = XPosition;
		this.YPosition = YPosition;
	}

	// getters and setters
	public int getY() {
		return YPosition;
	}

	public void setY(int YPosition) {
		this.YPosition = YPosition;
	}

	public int getX() {
		return XPosition;
	}

	public void setX(int XPosition) {
		this.XPosition = XPosition;
	}

	public String getImage() {
		return Image;
	}

	public void setImage(String Image) {
		this.Image = Image;
	}

	public String getName() {
		return Name;
	}

	public void setName(String Name) {
		this.Name = Name;
	}

}// End of class
