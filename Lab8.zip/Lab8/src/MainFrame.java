
/***********************************************************
 * Program Name: MainFrame.java Programmer: Patrick Malahowski Partner: Colin
 * Brust
 * Purpose: To generate game information in frame based on a panel.
 * file input. Last Changed Date: 4/4/2018
 * **********************************************************
 */

import javax.swing.JFrame;
import java.io.FileNotFoundException;

public class MainFrame {

	public static void main(String[] args) throws FileNotFoundException {
		// TODO Auto-generated method stub

		// Create the frame
		JFrame myFrame = new JFrame("Game");

		// set up the default close operation
		myFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		// Create an instance of the 'MainPanel' class
		MainPanel myPanel = new MainPanel();

		// Add myPanel to the frame
		myFrame.getContentPane().add(myPanel);

		// pack the frame
		myFrame.pack();

		// Make the frame visible
		myFrame.setVisible(true);

	}

}
