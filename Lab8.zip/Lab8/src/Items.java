import javax.swing.ImageIcon;

/***********************************************************
 * Program Name: Items.java Programmer: Patrick Malahowski Partner: Colin Brust
 * Purpose: To generate item information in a class. file input. Last Changed
 * Date: 4/4/2018 **********************************************************
 */

public class Items extends Entity {// Begin Class
	
	private ImageIcon itemImage;

	// initialize attributes
	public Items(String Name, String Image, int XPosition, int YPosition, ImageIcon itemImage) {
		super(Name, Image, XPosition, YPosition);
		this.itemImage = itemImage;
		// TODO Auto-generated constructor stub
	}

	// getters and setters
	public ImageIcon getImageIcon() {
		return itemImage;
	}
	
	public int getY() {
		return YPosition;
	}

	public void setY(int YPosition) {
		this.YPosition = YPosition;
	}

	public int getX() {
		return XPosition;
	}

	public void setX(int XPosition) {
		this.XPosition = XPosition;
	}

	public String getImage() {
		return Image;
	}

	public void setImage(String Image) {
		this.Image = Image;
	}

	public String getName() {
		return Name;
	}

	public void setName(String Name) {
		this.Name = Name;
	}

}// End of class
