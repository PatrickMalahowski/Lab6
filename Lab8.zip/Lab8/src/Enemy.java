/***********************************************************
 * Program Name: Enemy.java Programmer: Patrick Malahowski Partner: Colin
 * Brust Purpose: To generate enemy information in a class. file input. Last
 * Changed Date: 4/4/2018
 * **********************************************************
 */

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.Timer;

public class Enemy extends Entity {// Begin Class
	
	private MainPanel myPanel;
	private Player myPlayer;
	private boolean hasCollidedWithPlayer = false;
	
	private Timer myTimer = new Timer(47, new timerListener());
	
	// initialize attributes
	public Enemy(String Name, String Image, int XPosition, int YPosition, MainPanel myPanel) {
		super(Name, Image, XPosition, YPosition);
		
		this.myPanel = myPanel;
		myTimer.start();
		// TODO Auto-generated constructor stub
	}
	
	// getters and setters
		public int getY() {
			return YPosition;
		}

		public void setY(int YPosition) {
			this.YPosition = YPosition;
		}

		public int getX() {
			return XPosition;
		}

		public void setX(int XPosition) {
			this.XPosition = XPosition;
		}

		public String getImage() {
			return Image;
		}

		public void setImage(String Image) {
			this.Image = Image;
		}

		public String getName() {
			return Name;
		}

		public void setName(String Name) {
			this.Name = Name;
		}
		
		public void setPlayer(Player myPlayer)
		{
			this.myPlayer = myPlayer;
		}
		
		public Timer getMyTimer()
		{
			return myTimer;
		}
		public boolean hasTheEnemyCollidedWithPlayer()
		{
			return hasCollidedWithPlayer;
		}
		private class timerListener implements ActionListener
		{

			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				if(myPlayer.hasThePlayerCollidedWithEnemy())
				{
					myTimer.stop();
				}
				// this just looks for where the player is and then moves toward them
				if (myPlayer.getX() > getX()) {
					if (getX() > 1151) {
						setX(getX() + 0);
					} else {
						setX(getX() + 1);
					}
				} else if (myPlayer.getX() < getX()) {
					if (getX() < -3) {
						setX(getX() - 0);
					} else {
						setX(getX() - 1);
					}
				} else if (myPlayer.getY() > getY()) {
					if (getY() > 493) {
						setY(getY() + 0);
					} else {
						setY(getY() + 1);
					}
				} else if (myPlayer.getY() < getY()) {
					if (getY() < -3) {
						setY(getY() - 0);
					} else {
						setY(getY() - 1);
					}
				}

				// notice how we check collision from the enemy and the player
				hasCollidedWithPlayer = areRectsColliding(getX(), getX() + 134, getY(), getY() - 134,
						myPlayer.getX(), myPlayer.getX() + 134, myPlayer.getY(), myPlayer.getY() - 134);
				if(hasCollidedWithPlayer)
				{
					myTimer.stop();
					myPlayer.setThePlayerCollidedWithEnemy(true);
				}
				myPanel.repaint();
			}
			
		}
		
		private boolean areRectsColliding(int r1TopLeftX, int r1BottomRightX, int r1TopLeftY, int r1BottomRightY,
				int r2TopLeftX, int r2BottomRightX, int r2TopLeftY, int r2BottomRightY) {

			System.out.println(r1BottomRightX + " " + r2BottomRightX);

			if (r1TopLeftX < r2BottomRightX && r1BottomRightX > r2TopLeftX && r1TopLeftY > r2BottomRightY
					&& r1BottomRightY < r2TopLeftY) {
				System.out.println("getting here");
				return true;
			} else {
				return false;
			}
		}
	

}// End of class
