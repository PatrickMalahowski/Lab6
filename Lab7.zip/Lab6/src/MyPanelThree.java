import java.awt.Color;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileNotFoundException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class MyPanelThree extends JPanel {// Begin Class

	// variable declaration
	int GameDifficulty = 0;
	boolean PlayerWin = (true);
	JButton StartButton;
	MyPanel myPanel;
	JLabel CurrentScore;
	JLabel FirstPlaceScore;
	JLabel SecondPlaceScore;
	JLabel ThirdPlaceScore;
	JLabel ConsolationLabel;
	private String PlayerName;
	private String PlayerImage;
	private int PlayerScore;
	Game CurrentGame;
	Game FirstPlaceGame;
	Game SecondPlaceGame;
	Game ThirdPlaceGame;

	public MyPanelThree(String PlayerName, String PlayerImage, int PlayerScore) {// Begin Constructor
		this.PlayerName = PlayerName;
		this.PlayerImage = PlayerImage;
		this.setPlayerScore(PlayerScore);
		// favorite color
		setBackground(Color.ORANGE);
		// Set the dimensions of the panel
		setPreferredSize(new Dimension(1349, 691));

		CurrentGame = new Game(PlayerName, PlayerImage, PlayerScore);
		FirstPlaceGame = new Game("Not Enough Games Played", "", 0);
		SecondPlaceGame = new Game("Not Enough Games Played", "", 0);
		ThirdPlaceGame = new Game("Not Enough Games Played", "", 0);

		ConsolationLabel = new JLabel("");

		if (PlayerScore >= FirstPlaceGame.getPlayerScore()) {
			FirstPlaceGame.setPlayerName(PlayerName);
			FirstPlaceGame.setPlayerImage(PlayerImage);
			FirstPlaceGame.setPlayerScore(PlayerScore);
		} else if (PlayerScore < FirstPlaceGame.getPlayerScore() && PlayerScore >= SecondPlaceGame.getPlayerScore()) {
			SecondPlaceGame.setPlayerName(PlayerName);
			SecondPlaceGame.setPlayerImage(PlayerImage);
			SecondPlaceGame.setPlayerScore(PlayerScore);
		} else if (PlayerScore < SecondPlaceGame.getPlayerScore() && PlayerScore >= ThirdPlaceGame.getPlayerScore()) {
			ThirdPlaceGame.setPlayerName(PlayerName);
			ThirdPlaceGame.setPlayerImage(PlayerImage);
			ThirdPlaceGame.setPlayerScore(PlayerScore);
		} else {
			ConsolationLabel = new JLabel("Sorry you did not place. Keep playing! Better luck next time!");
		}

		if (PlayerWin == true) {
			GameDifficulty = GameDifficulty + 1;
		} else {
			GameDifficulty = 0;
		}

		CurrentScore = new JLabel("Current Score: " + CurrentGame.toString());
		FirstPlaceScore = new JLabel("First Place Score: " + FirstPlaceGame.toString());
		SecondPlaceScore = new JLabel("Second Place Score: " + SecondPlaceGame.toString());
		ThirdPlaceScore = new JLabel("Third Place Score: " + ThirdPlaceGame.toString());

		// creates button for switch
		StartButton = new JButton("Start!");
		StartButton.addActionListener(new buttonHandler());

		add(StartButton);
		add(CurrentScore);
		add(FirstPlaceScore);
		add(SecondPlaceScore);
		add(ThirdPlaceScore);
		add(ConsolationLabel);

		try {
			myPanel = new MyPanel(GameDifficulty);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}// End of constructor

	public int getPlayerScore() {
		return PlayerScore;
	}

	public void setPlayerScore(int playerScore) {
		PlayerScore = playerScore;
	}

	public void setPlayerWin(boolean PlayerWin) {
		this.PlayerWin = PlayerWin;
	}

	// handler
	private class buttonHandler implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent arg0) {
			// TODO Auto-generated method stub
			// PlayerNumber = generator.nextInt(2);
			JFrame myFrame = new JFrame("Game");
			myFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

			// Create an instance of the 'MyPanel' class

			// Add myPanel to the frame
			myFrame.getContentPane().add(myPanel);

			// Make the frame visible
			myFrame.pack();
			myFrame.setVisible(true);
			// System.exit(1);

		}

	}

}// End of class
