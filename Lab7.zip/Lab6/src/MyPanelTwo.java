import java.awt.Color;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileNotFoundException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

/***********************************************************
 * Program Name: MainFrame.java Programmer: Patrick Malahowski Partner: Colin
 * Brust Purpose: To generate game start screen in a panel. I have temporarily
 * added test code for the other classes to the button. Last Changed Date:
 * 3/8/2018 **********************************************************
 */
public class MyPanelTwo extends JPanel {// Begin Class

	// variable declaration
	JButton StartButton;
	MyPanel myPanel;
	JLabel ControlLabelOne;
	JLabel ControlLabelTwo;
	JLabel ControlLabelThree;
	JLabel ControlLabelFour;
	JLabel ControlLabelFive;
	int GameDifficulty = 0;

	public MyPanelTwo() {// Begin Constructor

		// favorite color
		setBackground(Color.RED);
		// Set the dimensions of the panel
		setPreferredSize(new Dimension(1349, 691));

		// Label creation
		ControlLabelOne = new JLabel("Use A to move left.");
		ControlLabelTwo = new JLabel("Use S to move down.");
		ControlLabelThree = new JLabel("Use W to move up.");
		ControlLabelFour = new JLabel("Use D to move right.");
		ControlLabelFive = new JLabel("Press the start button to start the game!");

		try {
			myPanel = new MyPanel(GameDifficulty);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		// creates button for switch
		StartButton = new JButton("Start!");
		StartButton.addActionListener(new buttonHandler());

		// add components
		add(StartButton);
		add(ControlLabelOne);
		add(ControlLabelTwo);
		add(ControlLabelThree);
		add(ControlLabelFour);
		add(ControlLabelFive);

	}// End of constructor

	public MyPanel getMyPanel() {
		return myPanel;
	}

	// handler
	private class buttonHandler implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent arg0) {
			// TODO Auto-generated method stub
			// PlayerNumber = generator.nextInt(2);
			JFrame myFrame = new JFrame("Game");
			myFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

			// Create an instance of the 'MyPanel' class

			// Add myPanel to the frame
			myFrame.getContentPane().add(myPanel);

			// Make the frame visible
			myFrame.pack();
			myFrame.setVisible(true);
			// System.exit(1);

		}

	}

}// End of class
