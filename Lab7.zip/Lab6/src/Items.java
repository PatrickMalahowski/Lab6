import java.awt.Color;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.Timer;

/***********************************************************
 * Program Name: MainFrame.java Programmer: Patrick Malahowski Partner: Colin
 * Brust Purpose: To generate item information in a class. file input. Last
 * Changed Date: 3/8/2018
 * **********************************************************
 */
public class Items {
	// variable declaration
	private String ItemName;
	private String ItemImage;
	private int ItemPositionX;
	private int ItemPositionY;
	private Player PlayerOne;
	private MyPanel jpanelPointer;
	public ImageIcon ItemIcon;
	private Image ItemImageOne;

	// initialize attributes
	public Items(String ItemName, String ItemImage, int ItemPositionX, int ItemPositionY, Player PlayerOne,
			MyPanel jpanelPointer) {
		this.ItemName = ItemName;
		this.ItemImage = ItemImage;
		this.ItemPositionX = ItemPositionX;
		this.ItemPositionY = ItemPositionY;
		this.PlayerOne = PlayerOne;
		this.jpanelPointer = jpanelPointer;
		this.ItemIcon = new ImageIcon(ItemImage);
		this.ItemImageOne = ItemIcon.getImage().getScaledInstance(200, 200, Image.SCALE_DEFAULT);
		this.ItemIcon.setImage(ItemImageOne);
		jpanelPointer.setFocusable(true);
		jpanelPointer.requestFocus();
	}

	// getters and setters.
	public String getImagePath() {
		return ItemImage;
	}

	public void setImagePath(String ItemImage) {
		this.ItemImage = ItemImage;
	}

	public void setImageIcon(ImageIcon ItemIcon) {
		this.ItemIcon = ItemIcon;
	}

	public int getX() {
		return ItemPositionX;
	}

	public int getY() {
		return ItemPositionY;
	}

	public void setX(int ItemPositionX) {
		this.ItemPositionX = ItemPositionX;
	}

	public void setY(int ItemPositionY) {
		this.ItemPositionY = ItemPositionY;
	}
}
