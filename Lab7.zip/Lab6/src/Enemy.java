import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.Timer;

/***********************************************************
 * Program Name: MainFrame.java Programmer: Patrick Malahowski Partner: Colin
 * Brust Purpose: To generate enemy information in a class. file input. Last
 * Changed Date: 3/8/2018
 * **********************************************************
 */
public class Enemy implements ActionListener {

	// variable declaration
	private String EnemyName;
	private String EnemyImage;
	private int PlayersKilled;
	private int EnemyPositionX;
	private int EnemyPositionY;
	private Player PlayerOne;
	private MyPanel jpanelPointer;
	Timer myTimer;

	// initialize attributes
	public Enemy(String EnemyName, String EnemyImage, int PlayersKilled, int EnemyPositionX, int EnemyPositionY,
			Player PlayerOne, MyPanel jpanelPointer) {
		this.EnemyName = EnemyName;
		this.EnemyImage = EnemyImage;
		this.PlayersKilled = PlayersKilled;
		this.EnemyPositionX = EnemyPositionX;
		this.EnemyPositionY = EnemyPositionY;
		this.PlayerOne = PlayerOne;
		this.jpanelPointer = jpanelPointer;
		jpanelPointer.setFocusable(true);
		jpanelPointer.requestFocus();
		myTimer = new Timer(47 - (jpanelPointer.getGameDifficulty() * 17), new timerListener());
		myTimer.start();

	}

	// getters and setters.
	public String getImagePath() {
		return EnemyImage;
	}

	public int getX() {
		return EnemyPositionX;
	}

	public int getY() {
		return EnemyPositionY;
	}

	public void setX(int EnemyPositionX) {
		this.EnemyPositionX = EnemyPositionX;
	}

	public void setY(int EnemyPositionY) {
		this.EnemyPositionY = EnemyPositionY;
	}

	// Enemy movement.
	private class timerListener implements ActionListener {
		@Override
		public void actionPerformed(ActionEvent arg0) {
			// TODO Auto-generated method stub
			if (PlayerOne.getX() > getX()) {
				if (getX() > 1151) {
					setX(getX() + 0);
				} else {
					setX(getX() + 1);
				}
			} else if (PlayerOne.getX() < getX()) {
				if (getX() < -3) {
					setX(getX() - 0);
				} else {
					setX(getX() - 1);
				}
			} else if (PlayerOne.getY() > getY()) {
				if (getY() > 493) {
					setY(getY() + 0);
				} else {
					setY(getY() + 1);
				}
			} else if (PlayerOne.getY() < getY()) {
				if (getY() < -3) {
					setY(getY() - 0);
				} else {
					setY(getY() - 1);
				}
			}

			// Enemy collision detection.
			Boolean overlap = jpanelPointer.m.areRectsColliding(getX(), getX() + 200, getY(), getY() - 200,
					PlayerOne.getX(), PlayerOne.getX() + 200, PlayerOne.getY(), PlayerOne.getY() - 200);

			if (overlap) {
				jpanelPointer.setBackground(Color.RED);

				jpanelPointer.PlayerOne.setX(2147483647);
				jpanelPointer.PlayerOne.setY(2147483647);
				jpanelPointer.myPanelThree.setPlayerWin(false);

				JFrame myFrame = new JFrame("Game");
				myFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

				// Create an instance of the 'MyPanel' class

				// Add myPanel to the frame
				myFrame.getContentPane().add(jpanelPointer.myPanelThree);

				// Make the frame visible
				myFrame.pack();
				myFrame.setVisible(true);
			}
			jpanelPointer.repaint();
		}
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub

	}

}
