import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

/***********************************************************
 * Program Name: MainFrame.java Programmer: Patrick Malahowski Partner: Colin
 * Brust Purpose: To generate movement information in a class. file input. Last
 * Changed Date: 3/8/2018
 * **********************************************************
 */
public class Movement implements KeyListener {
	// variable declaration
	MyPanel jpanelPointer;

	// initialize attributes
	public Movement(MyPanel jpanelPointer) {
		this.jpanelPointer = jpanelPointer;
		jpanelPointer.addKeyListener(this);
		jpanelPointer.setFocusable(true);
		jpanelPointer.requestFocus();

	}

	// Player movement.
	@Override
	public void keyPressed(KeyEvent arg0) {
		// TODO Auto-generated method stub
		Player playerPointer = jpanelPointer.getPlayer();
		if (arg0.getKeyCode() == KeyEvent.VK_A) {
			if (playerPointer.getX() < -1) {
				playerPointer.setX(playerPointer.getX() - 0);
			} else {
				playerPointer.setX(playerPointer.getX() - (1 + jpanelPointer.getGameDifficulty()));
			}
		}

		else if (arg0.getKeyCode() == KeyEvent.VK_D) {
			if (playerPointer.getX() > 1150) {
				playerPointer.setX(playerPointer.getX() + 0);
			} else {
				playerPointer.setX(playerPointer.getX() + (1 + jpanelPointer.getGameDifficulty()));
			}
		}

		else if (arg0.getKeyCode() == KeyEvent.VK_W) {
			if (playerPointer.getY() < -1) {
				playerPointer.setY(playerPointer.getY() - 0);
			} else {
				playerPointer.setY(playerPointer.getY() - (1 + jpanelPointer.getGameDifficulty()));
			}
		}

		else if (arg0.getKeyCode() == KeyEvent.VK_S) {
			if (playerPointer.getY() > 492) {
				playerPointer.setY(playerPointer.getY() + 0);
			} else {
				playerPointer.setY(playerPointer.getY() + (1 + jpanelPointer.getGameDifficulty()));
			}
		}
		jpanelPointer.repaint();
	}

	@Override
	public void keyReleased(KeyEvent arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void keyTyped(KeyEvent arg0) {
		// TODO Auto-generated method stub

	}

	// collision detection.
	public boolean areRectsColliding(int r1TopLeftX, int r1BottomRightX, int r1TopLeftY, int r1BottomRightY,
			int r2TopLeftX, int r2BottomRightX, int r2TopLeftY, int r2BottomRightY) {

		System.out.println(r1BottomRightX + " " + r2BottomRightX);

		if (r1TopLeftX < r2BottomRightX && r1BottomRightX > r2TopLeftX && r1TopLeftY > r2BottomRightY
				&& r1BottomRightY < r2TopLeftY) {
			System.out.println("getting here");
			return true;
		} else {
			return false;
		}
	}

}
