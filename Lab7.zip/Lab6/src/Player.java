import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import javax.swing.JPanel;

/***********************************************************
 * Program Name: MainFrame.java Programmer: Patrick Malahowski Partner: Colin
 * Brust Purpose: To generate player information in a class. file input. Last
 * Changed Date: 3/8/2018
 * **********************************************************
 */
public class Player {

	// variable declaration
	private String PlayerName;
	private String PlayerImage;
	private int PlayerItems;
	private int PlayerPositionX;
	private int PlayerPositionY;

	// initialize attributes
	public Player(String PlayerName, String PlayerImage, int PlayerItems, int PlayerPositionX, int PlayerPositionY) {
		this.PlayerName = PlayerName;
		this.PlayerImage = PlayerImage;
		this.setPlayerItems(PlayerItems);
		this.PlayerPositionX = PlayerPositionX;
		this.PlayerPositionY = PlayerPositionY;
	}

	// getters and setters
	public String getPlayerName() {
		return PlayerName;
	}

	public String getImagePath() {
		return PlayerImage;
	}

	public int getX() {
		return PlayerPositionX;
	}

	public int getY() {
		return PlayerPositionY;
	}

	public void setX(int PlayerPositionX) {
		this.PlayerPositionX = PlayerPositionX;
	}

	public void setY(int PlayerPositionY) {
		this.PlayerPositionY = PlayerPositionY;
	}

	public int getPlayerItems() {
		return PlayerItems;
	}

	public void setPlayerItems(int playerItems) {
		PlayerItems = playerItems;
	}
}
