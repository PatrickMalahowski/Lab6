import java.awt.Color;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyListener;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;
import java.awt.Graphics;
import java.awt.event.KeyEvent;
import java.awt.Image;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.Timer;

//import Items.timerListener;

import javax.swing.ImageIcon;

/***********************************************************
 * Program Name: MainFrame.java Programmer: Patrick Malahowski Partner: Colin
 * Brust Purpose: To generate game information in a panel based on other
 * classes. I feel the need to point out that I have put a lot of work in this I
 * have several additions over what is required. First the items randomly shift.
 * Secondly I actually have set boundaries, I am unsure if it is the final
 * method we are supposed to use, but the boundaries are set in both the enemies
 * and the players movement. Last Changed Date: 3/8/2018
 * **********************************************************
 */

public class MyPanel extends JPanel {// Begin Class

	// variable declaration
	private int GameDifficulty;

	MyPanelThree myPanelThree;
	Player PlayerOne;
	String PlayerName;
	String PlayerImage;
	int PlayerItems = 0;
	int PlayerPositionX;
	int PlayerPositionY;
	int PlayerNumber = 1;
	File myFile;
	JButton StartButton;
	JPanel StartPanel;
	ImageIcon myIcon;

	Random generator = new Random();
	Items[] ItemArray = new Items[5];
	Enemy EnemySkull;
	ImageIcon myIcon2;
	Image newImageTwo;
	Image newImage;
	Movement m;
	Timer myTimer;

	public MyPanel(int GameDifficulty) throws FileNotFoundException {// Begin Constructor
		this.GameDifficulty = GameDifficulty;

		// creates an instance of movement.
		m = new Movement(this);

		// set your background color here to your favorite color
		setBackground(Color.GREEN);
		// Set the dimensions of the panel
		setPreferredSize(new Dimension(1349, 691));

		// random player selection
		PlayerNumber = generator.nextInt(2);

		if (PlayerNumber == 0) {
			myFile = new File("./src/PlayerOne.csv");
		} else if (PlayerNumber == 1) {
			myFile = new File("./src/PlayerTwo.csv");
		}

		// declare and initialize Scanner object
		Scanner myScanner = new Scanner(myFile);

		// Player information loop which scans in the file, actual calculations
		// are in the Player class.
		while (myScanner.hasNextLine()) {

			String line = myScanner.nextLine();// each line

			Scanner myLineScanner = new Scanner(line);
			myLineScanner.useDelimiter(",");// break line into tokens by comma

			while (myLineScanner.hasNext()) {

				PlayerName = myLineScanner.next();
				PlayerImage = myLineScanner.next();
				PlayerItems = myLineScanner.nextInt();
				PlayerPositionX = myLineScanner.nextInt();
				PlayerPositionY = myLineScanner.nextInt();

				PlayerOne = new Player(PlayerName, PlayerImage, PlayerItems, PlayerPositionX, PlayerPositionY);
			} // inner while
		} // outer while

		ItemArray[0] = new Items("Candlestick", "./src/Candlestick.jpg", 1149 - generator.nextInt(22),
				0 + generator.nextInt(22), PlayerOne, (this));
		ItemArray[1] = new Items("Knife", "./src/Knife.jpg", 0 + generator.nextInt(22), 491 - generator.nextInt(22),
				PlayerOne, (this));
		ItemArray[2] = new Items("LeadPipe", "./src/LeadPipe.jpg", 574 - generator.nextInt(22),
				491 - generator.nextInt(22), PlayerOne, (this));
		ItemArray[3] = new Items("Revolver", "./src/Revolver.jpg", 574,
				245 + generator.nextInt(22) - generator.nextInt(22), PlayerOne, (this));
		ItemArray[4] = new Items("Wrench", "./src/Wrench.jpg", 574 - generator.nextInt(22), 0 + generator.nextInt(22),
				PlayerOne, (this));

		EnemySkull = new Enemy("enemyskull", "./src/Skull.jpg", 0, 1149, 491, PlayerOne, (this));
		myIcon2 = new ImageIcon(EnemySkull.getImagePath());
		newImageTwo = myIcon2.getImage().getScaledInstance(200, 200, Image.SCALE_DEFAULT);

		myIcon = new ImageIcon(PlayerOne.getImagePath());
		newImage = myIcon.getImage().getScaledInstance(200, 200, Image.SCALE_DEFAULT);

		myIcon.setImage(newImage);
		myIcon2.setImage(newImageTwo);

		myTimer = new Timer(600, new timerListener());
		myTimer.start();

	}// End of constructor

	public Player getPlayer() {
		return PlayerOne;
	}

	public int getGameDifficulty() {
		return GameDifficulty;
	}

	// paint component
	public void paintComponent(Graphics page) {
		super.paintComponent(page);
		page.drawImage(myIcon.getImage(), PlayerOne.getX(), PlayerOne.getY(), null);
		page.drawImage(myIcon2.getImage(), EnemySkull.getX(), EnemySkull.getY(), null);
		page.drawImage(ItemArray[0].ItemIcon.getImage(), ItemArray[0].getX(), ItemArray[0].getY(), null);
		page.drawImage(ItemArray[1].ItemIcon.getImage(), ItemArray[1].getX(), ItemArray[1].getY(), null);
		page.drawImage(ItemArray[2].ItemIcon.getImage(), ItemArray[2].getX(), ItemArray[2].getY(), null);
		page.drawImage(ItemArray[3].ItemIcon.getImage(), ItemArray[3].getX(), ItemArray[3].getY(), null);
		page.drawImage(ItemArray[4].ItemIcon.getImage(), ItemArray[4].getX(), ItemArray[4].getY(), null);
	}

	// timer for item collision detection.
	private class timerListener implements ActionListener {
		@Override
		public void actionPerformed(ActionEvent arg0) {
			// TODO Auto-generated method stub
			for (int i = 0; i < ItemArray.length; i++) {
				Boolean overlap = m.areRectsColliding(ItemArray[i].getX(), ItemArray[i].getX() + 200,
						ItemArray[i].getY(), ItemArray[i].getY() - 200, PlayerOne.getX(), PlayerOne.getX() + 200,
						PlayerOne.getY(), PlayerOne.getY() - 200);
				{

					if (overlap) {
						System.out.println("and here too");
						setBackground(Color.CYAN);
						ItemArray[i].setImageIcon(new ImageIcon());
						ItemArray[i].setX(-2102132736);
						ItemArray[i].setY(-2102132736);
						PlayerItems = PlayerItems + 1;
						PlayerOne.setPlayerItems(PlayerItems);
						myPanelThree = new MyPanelThree(PlayerOne.getPlayerName(), PlayerOne.getImagePath(),
								PlayerOne.getPlayerItems());
						System.out.println(PlayerOne.getPlayerItems());
						if (PlayerOne.getPlayerItems() == 5) {
							PlayerOne.setX(2102132736);
							PlayerOne.setY(2102132736);
							myPanelThree.setPlayerWin(true);

							JFrame myFrame = new JFrame("Game");
							myFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

							// Create an instance of the 'MyPanel' class

							// Add myPanel to the frame
							myFrame.getContentPane().add(myPanelThree);

							// Make the frame visible
							myFrame.pack();
							myFrame.setVisible(true);
						}
						break;
					} else {
						setBackground(Color.GREEN);
					}
					repaint();
				}
			}
		}
	}
}// End of class
