
/***********************************************************
 * Program Name: MainFrame.java Programmer: Patrick Malahowski Partner: Colin
 * Brust
 * Purpose: To generate game information in frame based on a panel.
 * file input. Last Changed Date: 3/8/2018
 * **********************************************************
 */
import java.io.FileNotFoundException;

import javax.swing.JFrame;

public class MainFrame {

	private static MyPanelTwo myPanelTwo;

	public static void main(String[] args) throws FileNotFoundException {
		// TODO Auto-generated method stub

		// Create the frame
		JFrame myFrame = new JFrame("Game");
		myFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		// Create an instance of the 'MyPanel' class
		myPanelTwo = new MyPanelTwo();

		// Add myPanel to the frame
		myFrame.getContentPane().add(myPanelTwo);

		// Make the frame visible
		myFrame.pack();
		myFrame.setVisible(true);

	}

	public static MyPanelTwo getMyPanelTwo() {
		return myPanelTwo;
	}

}
