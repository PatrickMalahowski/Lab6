/***********************************************************
 * Program Name: MainFrame.java Programmer: Patrick Malahowski Partner: Colin
 * Brust Purpose: To generate game information in a class. file input. Last
 * Changed Date: 3/8/2018
 * **********************************************************
 */
public class Game {

	// variable declaration
	private String PlayerName;
	private String PlayerImage;
	private int PlayerScore;

	// initialize attributes
	public Game(String PlayerName, String PlayerImage, int PlayerScore) {
		this.PlayerName = PlayerName;
		this.PlayerImage = PlayerImage;
		this.PlayerScore = PlayerScore;
	}

	public String getImagePath() {
		return PlayerImage;
	}

	public int getPlayerScore() {
		return PlayerScore;
	}

	public void setPlayerName(String PlayerName) {
		this.PlayerName = PlayerName;
	}

	public void setPlayerImage(String PlayerImage) {
		this.PlayerImage = PlayerImage;
	}

	public void setPlayerScore(int PlayerScore) {
		this.PlayerScore = PlayerScore;
	}

	// to string to print out data.
	public String toString() {
		return " Player Name: " + PlayerName + " Player Score: " + PlayerScore + " ";
	}

}
